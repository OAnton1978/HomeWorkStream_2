package com.company;

public enum Education {
    ELEMENTARY,
    SECONDARY,
    FURTHER,
    HIGHER
}
