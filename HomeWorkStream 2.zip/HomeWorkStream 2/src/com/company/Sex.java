package com.company;

public enum Sex {
    MAN,
    WOMEN
}